from pathlib import Path
import pandas as pd, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent
p=root/'prime_review'
(root/'figures').mkdir(exist_ok=True)
a=pd.read_csv(p/'agreement_budget.csv').query('mode=="all_unique"')
d=pd.read_csv(p/'cross_protease_witnesses.csv').query('mode=="all_unique" and margin==0 and cycle_delta>1e-8')
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150})
fig,ax=plt.subplots(1,2,figsize=(8,3.2),constrained_layout=True)
x=a.lower_compatible_per_assay;y=a.upper_both_nonadditive
maxval=max(x.max(),y.max())
ax[0].scatter(x,y,s=9,alpha=.55,color='#22577a',edgecolors='none')
ax[0].plot([0,maxval],[0,maxval],color='#777777',lw=1,ls='--')
ax[0].set(xlabel='Shared compatibility minimum',ylabel='Separate additive minimum (smaller)',title='A | Equal-tolerance endpoints')
ax[1].hist(a.both_window,bins=24,color='#22577a',edgecolor='white')
ax[1].axvline(a.both_window.median(),color='#b34738',lw=1.5,ls='--',label='Median 0.505')
ax[1].set(xlabel='Positive window width (kcal/mol)',ylabel='Panels',title='B | Window distribution');ax[1].legend(frameon=False,fontsize=9)
fig.savefig(root/'figures'/'agreement.png',dpi=210);plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(8,3.1),sharey=True,constrained_layout=True)
for i,(tag,name) in enumerate([('t','Trypsin to chymotrypsin'),('c','Chymotrypsin to trypsin')]):
    q=d[d.discovery==tag].dropna(subset=['holdout_cycle_delta'])
    ax[i].scatter(q.cycle_delta,q.holdout_cycle_delta,s=8,alpha=.55,color='#22577a',edgecolors='none')
    ax[i].axhline(0,color='#777777',lw=1)
    m=max(q.cycle_delta.max(),q.holdout_cycle_delta.max())
    ax[i].plot([0,m],[0,m],ls='--',lw=1,color='#aaaaaa')
    ax[i].set(xlabel='Source score (kcal/mol)',title=name)
    ax[i].text(.03,.96,f'n = {len(q)} assessable',transform=ax[i].transAxes,va='top',fontsize=9)
ax[0].set_ylabel('Fixed target score (kcal/mol)')
fig.savefig(root/'figures'/'transfer.png',dpi=210);plt.close(fig)
