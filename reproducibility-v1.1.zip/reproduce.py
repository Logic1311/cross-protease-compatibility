#!/usr/bin/env python3
"""Re-run from the pinned processed data; analysis commands overwrite derived outputs."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
source = root / "data" / "Processed_K50_dG_datasets.zip"
if not source.is_file():
    raise SystemExit("Missing data/Processed_K50_dG_datasets.zip; see the Zenodo record in README.md.")
if sys.flags.optimize:
    raise SystemExit("Run without Python -O; analysis checks require assertions.")
for script in ("prime_review/cross_protease.py", "prime_review/agreement_budget.py",
               "prime_review/integer_certificates.py", "figures.py"):
    subprocess.run([sys.executable, str(root / script)], cwd=root, check=True)
