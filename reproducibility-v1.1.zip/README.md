# Censor-aware compatibility budgets for paired protein-folding assays

**AI-assisted research preprint v1.1, 26 November 2026. Not peer reviewed. Human authorship and affiliation pending.** This repository releases a model-conditional methods contribution, not evidence of a newly established universal physical law.

- [Manuscript (PDF)](manuscript/manuscript.pdf)
- [Manuscript source](manuscript/manuscript.md)
- [Paired budget results](prime_review/agreement_budget.csv)
- [Fixed witness transfer results](prime_review/cross_protease_witnesses.csv)
- [Integer interval proof (Lean 4)](prime_review/Compatibility.lean)
- [Review and novelty record](REVIEW.md)

Given individual additive defects D_T and D_C, and difference defect D_J for two interval arrays, a common unrestricted landscape with an additive assay offset is feasible exactly when e_T+e_C >= D_J. A shared additive landscape instead requires e_T >= D_T and e_C >= D_C. The nonempty equal-tolerance window [D_J/2, min(D_T,D_C)) occurs in 549/559 measured panels (median width 0.5047 kcal/mol).

The individual graph optimization is classical; the paired budget is a direct consequence of interval intersection and additive offsets. Novelty is limited to this diagnostic formulation and its application. The paired budget and fixed signed witness transfer are the focus. The source already established thermodynamic coupling and compared proteases. All claims are conditional on the supplied bounds; marginal intervals are not simultaneous confidence regions, and the assays share systematics.

## Reproduction

Original data: Tsuboyama et al., Nature 620, 434–444 (2023), DOI 10.1038/s41586-023-06328-6; Zenodo DOI 10.5281/zenodo.7992926, v2_230420. Download only the published processed archive to data/Processed_K50_dG_datasets.zip.

Source: https://zenodo.org/records/7992926

Archive size: 1,013,678,473 bytes. MD5: f7e8c553efee734cf161ee6f2b0a09cf. The large original archive is not included. Derived tables contain results from the attributed source, not new experimental measurements.

Use Python 3.11 and the pinned versions in requirements.txt (versions used in the verification environment). From the repository root:

    python -m pip install -r requirements.txt
    python reproduce.py
    lean prime_review/Compatibility.lean

The reproduction script checks the pinned archive, runs the three analysis programs and regenerates figures. Its first analysis program extracts the source and writes prime_review/raw_dual_protease.csv.gz locally. The latter is an intermediate, excluded from the release. The analysis scripts rewrite the result tables; floating-point rounding and equivalent optimal-cycle tie choices can vary across solver versions. The exact rounded certificates validate each reported baseline optimum. The separate joint LP checks a deterministic panel subset for both masks. The Lean proof covers the integer interval criterion, not the full real-valued graph theorem or experimental inference. The main paper contains the analytic proof.

Optional PDF regeneration works with Times New Roman/Arial on Windows or Liberation Serif/DejaVu Serif on Linux; font files are not included:

    python render_manuscript.py --root .

See the source audit and verification logs in prime_review/. SHA256SUMS.txt lists the published file hashes excluding itself and the Git metadata.

## Attribution and release scope

AI-assisted research, unreviewed. Human authorship is pending. Cite the original MegaScale data and papers. No license is asserted over third-party data beyond the original source's terms. No personal information, credentials, original sequencing archive, or private project files are intentionally included. The work does not claim verified priority across all literature, universal thermodynamic coupling prevalence, or independent wet-lab confirmation. This repository contains the research version and reproducibility materials, not a journal acceptance.
