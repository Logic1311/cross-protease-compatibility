"""Exact two-assay compatibility window under additive assay offsets.
The main estimands are deterministic, conditional on published intervals.
The observed protein data are not assumed to have independent assay errors.
"""
import argparse, json, hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
from cross_protease import clean, get_source, interval, weights, optimum

def joint_lp(LT,UT,LC,UC):
    # 400 latent cells + 40 additive C-vs-T offsets + 2 assay tolerances.
    # Gauge: absorb the T additive offset into the common latent matrix.
    ii=[];jj=[];vv=[];rhs=[]
    for assay,L,U in [(0,LT,UT),(1,LC,UC)]:
        for i in range(20):
            for j in range(20):
                for bound,sgn in [(U[i,j],1.),(-L[i,j],-1.)]:
                    if not np.isfinite(bound): continue
                    r=len(rhs);rhs.append(bound)
                    ii.append(r);jj.append(20*i+j);vv.append(sgn)
                    if assay:
                        ii.extend([r,r]);jj.extend([400+i,420+j]);vv.extend([sgn,sgn])
                    ii.append(r);jj.append(440+assay);vv.append(-1.)
    if not rhs:return 0.
    A=coo_matrix((vv,(ii,jj)),shape=(len(rhs),442)).tocsr()
    res=linprog(np.r_[np.zeros(440),1.,1.],A_ub=A,b_ub=rhs,bounds=[(None,None)]*440+[(0,None)]*2,method='highs')
    assert res.success,res.message
    return float(res.fun)
def full_joint_window(LT,UT,LC,UC):
    DT,_=optimum(weights(LT,UT)); DC,_=optimum(weights(LC,UC))
    # Minkowski interval difference. Missing observations are (-inf,+inf).
    LO=LT-UC; HI=UT-LC
    DD,_=optimum(weights(LO,HI))
    assert DD<=DT+DC+1e-7
    return DT,DC,DD
def main(root):
    # Test with complete synthetic identical/antagonistic additive-offset views.
    base=np.arange(20.)[:,None]+.7*np.arange(20.)[None,:]
    rng=np.random.default_rng(20261126)
    h=rng.normal(size=(20,20))
    for T,C in [(base,2*base),(h,h+base),(h,-h+base),(h,.25*h+base)]:
        x,y,z=full_joint_window(T,T,C,C)
        j=joint_lp(T,T,C,C);assert abs(j-z)<1e-7
        if np.allclose(T-C,-base) and np.allclose(T,h): assert z<1e-7
        if np.allclose(C,-h+base): assert abs(z-2*x)<1e-7
    print('SYNTHETIC JOINT-LP CHECKS PASS',flush=True)
    # Replay from the independently extracted source table produced by cross_protease.py.
    path=root/'prime_review'/'raw_dual_protease.csv.gz'
    raw=pd.read_csv(path,low_memory=False)
    d,audit=clean(raw)
    rows=[]
    for panel,g in d.groupby('pair_name',sort=True):
        for subset,mask in [('all_unique',False),('joint_quality_mask',True)]:
            Lt,Ut,nt=interval(g,'t',mask)
            Lc,Uc,nc=interval(g,'c',mask)
            DT,DC,DD=full_joint_window(Lt,Ut,Lc,Uc)
            common=np.isfinite(Lt)&np.isfinite(Ut)&np.isfinite(Lc)&np.isfinite(Uc)
            # deterministic sample selected by SHA256, independently of outcomes.
            sample=int(hashlib.sha256(panel.encode()).hexdigest()[:8],16)%10==0
            j=joint_lp(Lt,Ut,Lc,Uc) if sample else np.nan
            if sample: assert abs(j-DD)<1e-7,(panel,j,DD)
            rows.append(dict(panel=panel,mode=subset,n=nt,n_c=nc,n_joint_twosided=int(common.sum()),delta_t=DT,delta_c=DC,delta_diff=DD,
                lower_compatible_per_assay=DD/2,upper_both_nonadditive=min(DT,DC),both_window=max(0.,min(DT,DC)-DD/2),
                upper_additive_null=max(DT,DC),window=max(DT,DC)-DD/2,delta_sum_deficit=DT+DC-DD,joint_lp=j))
        if len(rows)%200==0:print('JOINT',len(rows)//2,flush=True)
    a=pd.DataFrame(rows)
    a.to_csv(root/'prime_review'/'agreement_budget.csv',index=False,float_format='%.12g')
    summary=[]
    for mode,g in a.groupby('mode'):
        for name,b in [('all',g),('coverage350',g[g.n>=350]),('coverage350_joint_twosided250',g[(g.n>=350)&(g.n_joint_twosided>=250)])]:
            q=b.both_window
            summary.append(dict(mode=mode,subset=name,n=len(b),both_positive=int((q>1e-8).sum()),both_gt025=int((q>.25).sum()),both_gt05=int((q>.5).sum()),median_window=float(q.median()),
                median_t=float(b.delta_t.median()),median_c=float(b.delta_c.median()),median_diff=float(b.delta_diff.median()),
                median_required_eta=float(b.lower_compatible_per_assay.median()),n_joint_checked=int(b.joint_lp.notna().sum()),max_joint_diff=float((b.joint_lp-b.delta_diff).abs().max())))
    s=pd.DataFrame(summary)
    s.to_csv(root/'prime_review'/'agreement_summary.csv',index=False)
    print(s.to_string(index=False),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);main(p.parse_args().root)
