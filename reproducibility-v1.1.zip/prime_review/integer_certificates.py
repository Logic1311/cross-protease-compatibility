"""Integer audit of every reported two-assay and difference optimum.

Intervals are rounded *outward* to a grid of 1e-9 kcal/mol (using a
slightly conservative 1e-5 guard in scaled units). A directed cycle and
an integer shortest-path potential certify a sharp optimum for the
rounded intervals; the original optimum differs by at most two grid
units for each difference interval, plus floating parsing error.
"""
import json, argparse
from pathlib import Path
import numpy as np
import pandas as pd
from cross_protease import clean, interval, weights, optimum
S=10**9
def exact(W):
    u,v=np.where(np.isfinite(W))
    # W are upper inequality bounds; ceil makes each constraint weaker.
    # Numerical guard ensures outward rounding except at sub-1e-14 errors.
    wi=[int(np.ceil(float(W[a,b])*S+1e-5)) for a,b in zip(u,v)]
    pairs=[(int(a),int(b)) for a,b in zip(u,v)]
    Q=np.full((40,40),np.inf)
    for (a,b),w in zip(pairs,wi):Q[a,b]=w/S
    d,c=optimum(Q)
    dic=dict(zip(pairs,wi))
    if c:
        m=len(c)
        n=-sum(dic[(int(a),int(b))] for a,b in zip(c,c[1:]+c[:1]))
        assert n>0
    else:n,m=0,1
    # All-source Bellman-Ford with exact Python integer weights.
    # A potential validates all difference inequalities at n/m scaled units.
    dist=[0]*40
    arcs=[(a,b,m*w+n) for (a,b),w in zip(pairs,wi)]
    for _ in range(39):
        changed=False
        for a,b,w in arcs:
            z=dist[a]+w
            if dist[b]>z:dist[b]=z;changed=True
        if not changed:break
    assert all(dist[b]-dist[a]<=w for a,b,w in arcs),('not exact',n,m,c)
    return n/(m*S), n,m,[int(x) for x in c]

def main(root):
    raw=pd.read_csv(root/'prime_review'/'raw_dual_protease.csv.gz',low_memory=False)
    d,_=clean(raw)
    ref=pd.read_csv(root/'prime_review'/'agreement_budget.csv').set_index(['panel','mode'])
    rows=[]
    for p,g in d.groupby('pair_name',sort=True):
        for mode,mask in [('all_unique',False),('joint_quality_mask',True)]:
            LT,UT,_=interval(g,'t',mask);LC,UC,_=interval(g,'c',mask)
            out={'panel':p,'mode':mode}
            for label,W,col in [('T',weights(LT,UT),'delta_t'),('C',weights(LC,UC),'delta_c'),('D',weights(LT-UC,UT-LC),'delta_diff')]:
                val,n,m,c=exact(W)
                err=abs(val-ref.loc[(p,mode),col])
                assert err<3e-9,(p,mode,label,err)
                out.update({label+'_exact':val,label+'_n':n,label+'_den':m,label+'_cycle':json.dumps(c),label+'_difference':err})
            rows.append(out)
        if len(rows)%200==0:print('INTEGER VERIFIED',len(rows)//2,flush=True)
    x=pd.DataFrame(rows);x.to_csv(root/'prime_review'/'integer_certificates.csv',index=False,float_format='%.12g')
    print('INTEGER CERTIFICATES',len(x)*3,'MAX_ERROR',x[['T_difference','C_difference','D_difference']].max().max(),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);main(p.parse_args().root)
