"""Independent reanalysis of the pinned MegaScale processed table.
No imports from the original agent's code. All paths relative to --root.
Predefined analysis: each of the two assays selects its own extremal
cycle and quartet; the *same directed witness* is scored on the other
assay. Source-quality masks are explicitly joint-data-conditioned.
No assumption of independence of biological or assay-model errors.
"""
import argparse, hashlib, json, re, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.sparse import csr_matrix
AA='ACDEFGHIKLMNPQRSTVWY'
PAT=r'^([A-Z])(\d+)([A-Z]):([A-Z])(\d+)([A-Z])$'
def get_source(root):
    z=root/'data'/'Processed_K50_dG_datasets.zip'
    h=hashlib.md5()
    with z.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    assert h.hexdigest()=='f7e8c553efee734cf161ee6f2b0a09cf'
    with zipfile.ZipFile(z) as f:
        names=f.namelist()
        name=next(n for n in names if n.startswith('Processed_K50_dG_datasets/') and n.endswith('Tsuboyama2023_Dataset2_Dataset3_20230416.csv'))
        cols=['name','mut_type','pair_name','WT_name','WT_cluster','dG_ML','deltaG','deltaG_95CI_low','deltaG_95CI_high','deltaG_t','deltaG_t_95CI_low','deltaG_t_95CI_high','deltaG_c','deltaG_c_95CI_low','deltaG_c_95CI_high','aa_seq']
        pieces=[]
        for c in pd.read_csv(f.open(name),usecols=cols,chunksize=100000,low_memory=False):
            pieces.append(c[c.pair_name.notna() & c.pair_name.ne('')])
        raw=pd.concat(pieces,ignore_index=True)
        sm=pd.read_csv(f.open(next(n for n in names if n.startswith('Processed_K50_dG_datasets/') and n.endswith('/Single_DMS_list.csv'))))
        dm=pd.read_csv(f.open(next(n for n in names if n.startswith('Processed_K50_dG_datasets/') and n.endswith('/Double_DMS_list.csv'))))
    return raw, sm, dm
def clean(raw):
    m=raw.mut_type.str.extract(PAT)
    assert m.notna().all().all()
    raw=raw.assign(pos1=m[1].astype(int),pos2=m[4].astype(int),i=m[2].map({a:i for i,a in enumerate(AA)}),j=m[5].map({a:i for i,a in enumerate(AA)}))
    assert raw.i.notna().all() and raw.j.notna().all()
    assert raw.pos1.ne(raw.pos2).all()
    assert (raw.groupby('pair_name')[['pos1','pos2']].nunique()==1).all().all()
    # Check actual sequence identities and background at all other positions.
    seqok=[]; backgrounds=[]
    for seq,a,b,i,j in zip(raw.aa_seq,raw.pos1,raw.pos2,raw.i,raw.j):
        if isinstance(seq,str) and 1<=a<=len(seq) and 1<=b<=len(seq):
            seqok.append(seq[a-1]==AA[i] and seq[b-1]==AA[j])
            s=list(seq);s[a-1]='?';s[b-1]='?';backgrounds.append(''.join(s))
        else:
            seqok.append(False);backgrounds.append('')
    raw=raw.assign(seqok=seqok,background=backgrounds)
    bad_bg=raw.groupby('pair_name').background.nunique()
    bad_panels=set(bad_bg[bad_bg.ne(1)].index)|set(raw.loc[~raw.seqok,'pair_name'])
    dup=raw.duplicated(['pair_name','i','j'],keep=False)
    d=raw[~dup & ~raw.pair_name.isin(bad_panels)].copy()
    print('SOURCE',len(raw),raw.pair_name.nunique(),'dup rows',int(dup.sum()),'sequence mismatches',int((~raw.seqok).sum()),'bad panels',len(bad_panels),'retained',len(d),d.pair_name.nunique(),flush=True)
    return d, {'raw_rows':len(raw),'raw_panels':raw.pair_name.nunique(),'duplicate_rows':int(dup.sum()),'bad_sequence_rows':int((~raw.seqok).sum()),'bad_background_panels':sorted(bad_panels),'retained_rows':len(d)}
def interval(g, tag, restrict=False, margin=0., window=(-1.,5.)):
    base='deltaG'+('_'+tag if tag else '')
    x=g[base].to_numpy(float)
    l=g[base+'_95CI_low'].to_numpy(float);u=g[base+'_95CI_high'].to_numpy(float)
    valid=np.isfinite(x)&np.isfinite(l)&np.isfinite(u)&(l<=u)
    if restrict: valid &= g.dG_ML.astype(str).str.strip().ne('-').to_numpy()
    # The censoring thresholds are the published assay dynamic range.
    # Widen intervals rather than use unreliable saturated point estimates.
    a,b=window
    xc=np.clip(x,a,b)
    l=np.minimum(l,xc);u=np.maximum(u,xc)
    l=np.where(xc<=a,-np.inf,l)-margin
    u=np.where(xc>=b,np.inf,u)+margin
    L=np.full((20,20),-np.inf);U=np.full((20,20),np.inf)
    i=g.i.to_numpy(int);j=g.j.to_numpy(int)
    L[i[valid],j[valid]]=l[valid];U[i[valid],j[valid]]=u[valid]
    return L,U,int(valid.sum())
def weights(L,U):
    W=np.full((40,40),np.inf)
    W[:20,20:]=-L
    W[20:,:20]=U.T
    return W
def score(W,cyc):
    if not cyc: return np.nan
    w=np.array([W[a,b] for a,b in zip(cyc,cyc[1:]+cyc[:1])])
    return -float(w.mean()) if np.isfinite(w).all() else np.nan
def find_cycle(adj):
    color=np.zeros(40,int);stack=[]
    def dfs(a):
        color[a]=1;stack.append(a)
        for b in adj[a]:
            if color[b]==1: return stack[stack.index(b):].copy()
            if color[b]==0:
                c=dfs(b)
                if c is not None:return c
        stack.pop();color[a]=2
    for a in range(40):
        if color[a]==0:
            c=dfs(a)
            if c is not None:return c
    return []
def optimum(W):
    u,v=np.where(np.isfinite(W)); w=W[u,v]
    A=np.zeros((len(u),41))
    k=np.arange(len(u));A[k,v]=1;A[k,u]-=1;A[:,-1]=-1
    if not len(u):return 0.,[]
    res=linprog(np.r_[np.zeros(40),1.],A_ub=csr_matrix(A),b_ub=w,bounds=[(None,None)]*40+[(0,None)],method='highs')
    assert res.success,res.message
    val=float(res.fun)
    if val<1e-9:return 0.,[]
    adj=[[] for _ in range(40)]
    for a,b,m in zip(u,v,res.ineqlin.marginals):
        if m < -1e-8:adj[a].append(b)
    cyc=find_cycle(adj)
    assert len(cyc)>=4 and len(cyc)==len(set(cyc)),(val,cyc)
    assert abs(score(W,cyc)-val)<1e-7,(val,score(W,cyc),cyc)
    return val,cyc
def best_quartet(L,U):
    # L[i,j]+L[k,l]-U[i,l]-U[k,j] is the directed 4-cycle contradiction.
    c=L[:,None,:,None]+L[None,:,None,:]-U[:,None,None,:]-U[None,:,:,None]
    # Same-row or same-column cycles cannot have positive gap; exclude explicitly.
    for x in range(20):c[x,x,:,:]=-np.inf;c[:,:,x,x]=-np.inf
    idx=np.unravel_index(np.argmax(c),c.shape)
    val=float(c[idx])/4
    if val<=0:return 0.,[]
    i,k,j,l=idx
    cyc=[int(i),20+int(j),int(k),20+int(l)]
    return val,cyc
def independent_raw_combined(d,root):
    # Rebuild combined observation intervals independently and cross-check the previous file.
    a=d[d.dG_ML.astype(str).str.strip().ne('-')].copy()
    v=a.dG_ML.astype(str).str.strip()
    a['point']=pd.to_numeric(v,errors='coerce')
    a.loc[v.str.startswith('<'),'point']=-1
    a.loc[v.str.startswith('>'),'point']=5
    a=a[a.point.notna()]
    a['point']=a.point.clip(-1,5)
    x=a.point.to_numpy(float)
    a['lo']=np.where(x<=-1,-np.inf,np.minimum(a.deltaG_95CI_low,x))
    a['hi']=np.where(x>=5,np.inf,np.maximum(a.deltaG_95CI_high,x))
    previous=root/'data'/'curated_original_intervals_reconstructed.csv.gz'
    if not previous.exists():
        assert len(a)==207381
        print('SOURCE COMBINED REBUILD',len(a),'legacy comparison file not required',flush=True)
        return len(a)
    old=pd.read_csv(root/'data'/'curated_original_intervals_reconstructed.csv.gz',low_memory=False)
    k=['pair_name','mut_type']
    m=a.merge(old,on=k,validate='one_to_one',suffixes=('_new','_old'))
    assert len(a)==len(old)==len(m)
    assert np.allclose(m.lo,m.ci_interval_lower) and np.allclose(m.hi,m.ci_interval_upper)
    print('INDEPENDENT SOURCE REBUILD',len(m),'intervals matched',flush=True)
    return len(m)
def test():
    a=np.arange(20.)[:,None]+np.arange(20.)[None,:]/3
    v,c=optimum(weights(a,a)); assert v<1e-8
    L=np.full((20,20),-np.inf);U=np.full((20,20),np.inf)
    M=np.array([[.5,1,0],[0,.5,1],[1,0,.5]])
    L[:3,:3]=U[:3,:3]=M
    W=weights(L,U)
    val,cyc=optimum(W);q,cyq=best_quartet(L,U)
    assert abs(val-.5)<1e-8 and abs(q-.375)<1e-8
    assert abs(score(W,cyq)-q)<1e-8
    assert abs(score(W,cyc)-val)<1e-8
    # Row/column additive assay shifts cancel in every directed witness.
    shift=np.arange(20.)[:,None]-np.arange(20.)[None,:]*.3
    assert abs(score(weights(L+shift,U+shift),cyc)-val)<1e-8
    print('SYNTHETIC EXACT AND SHIFT TESTS PASS',flush=True)
def main(root):
    test()
    raw,sm,dm=get_source(root)
    (root/'prime_review').mkdir(exist_ok=True)
    raw.to_csv(root/'prime_review'/'raw_dual_protease.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    d,audit=clean(raw)
    audit['combined_rebuilt_count']=independent_raw_combined(d,root)
    qm=dm.set_index('double_mut_name')
    ss=sm.set_index('name')
    records=[]
    for panel,g in d.groupby('pair_name',sort=True):
        # Primary: all unique, sequence-verified source variants; each assay's own intervals.
        # Sensitivity: source-model combined quality mask.
        for mode,restrict in [('all_unique',False),('joint_quality_mask',True)]:
            for margin in [0.,.25,.5]:
                views={}
                for tag in ['t','c']:
                    L,U,n=interval(g,tag,restrict,margin)
                    W=weights(L,U);val,cyc=optimum(W);q,cq=best_quartet(L,U)
                    assert q<=val+1e-7
                    assert not cq or abs(score(W,cq)-q)<1e-7
                    views[tag]=(W,val,cyc,q,cq,n)
                for a,b in [('t','c'),('c','t')]:
                    W,v,c,q,cq,n=views[a]
                    W2,v2,c2,q2,cq2,n2=views[b]
                    rec={'panel':panel,'mode':mode,'margin':margin,'discovery':a,'validation':b,'n_discovery':n,'n_validation':n2,'WT_name':g.WT_name.iloc[0],
                        'WT_cluster':str(g.WT_cluster.iloc[0]),'cycle_delta':v,'cycle_len':len(c),'cycle_nodes':json.dumps([int(x) for x in c]),'quartet_delta':q,'quartet_nodes':json.dumps([int(x) for x in cq]),
                        'holdout_cycle_delta':score(W2,c),'holdout_quartet_delta':score(W2,cq),'holdout_optimum':v2,'holdout_best_quartet':q2,
                        'dg_corr':qm.loc[panel,'dg_corr'],'K50_corr':qm.loc[panel,'K50_corr']}
                    records.append(rec)
        if len(records)%1200==0:print('PANELS',len(records)//12,flush=True)
    out=root/'prime_review';out.mkdir(exist_ok=True)
    r=pd.DataFrame(records)
    r.to_csv(out/'cross_protease_witnesses.csv',index=False,float_format='%.12g')
    rows=[]
    for (mode,margin,discovery),g in r.groupby(['mode','margin','discovery']):
        for subset,gg in [('all',g),('coverage350',g[g.n_discovery>=350]),('coverage350_high_quality',g[(g.n_discovery>=350)&(g.dg_corr>=.9)&(g.K50_corr>=.9)])]:
            selected=gg[gg.cycle_delta>1e-8]
            strong=gg[gg.cycle_delta>.25]
            long=gg[(gg.cycle_delta-gg.quartet_delta)>.01]
            row=dict(mode=mode,margin=margin,discovery=discovery,subset=subset,n=len(gg),n_positive=len(selected),
                n_validated=int((selected.holdout_cycle_delta>1e-8).sum()),n_assessable=int(selected.holdout_cycle_delta.notna().sum()),
                median_holdout=float(selected.holdout_cycle_delta.median()),n_strong=len(strong),n_strong_validated=int((strong.holdout_cycle_delta>.25).sum()),
                n_long=len(long),n_long_validated=int((long.holdout_cycle_delta>1e-8).sum()),
                n_long_better_holdout=int(((long.holdout_cycle_delta-long.holdout_quartet_delta)>.01).sum()))
            rows.append(row)
    summary=pd.DataFrame(rows)
    summary.to_csv(out/'cross_protease_summary.csv',index=False)
    (out/'source_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print(summary[(summary['margin']==0)&(summary['mode']=='all_unique')].to_string(index=False),flush=True)
    print(summary[(summary['margin']==.25)&(summary['mode']=='all_unique')].to_string(index=False),flush=True)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);args=a.parse_args()
    main(args.root)
