import Lean.Elab.Tactic.Omega

namespace AssayCompatibility

def Lower : Option Int → Int → Prop
  | none, _ => True
  | some a, x => a ≤ x

def Upper : Option Int → Int → Prop
  | none, _ => True
  | some a, x => x ≤ a

def Valid : Option Int → Option Int → Prop
  | some a, some b => a ≤ b
  | _, _ => True

def SubOpt : Option Int → Option Int → Option Int
  | some a, some b => some (a-b)
  | _, _ => none

def AddOpt (a : Option Int) (s : Int) : Option Int :=
  a.map (fun x => x+s)

def Pick (l₁ l₂ u₁ u₂ : Option Int) : Int :=
  match l₁,l₂ with
  | some a,some b => max a b
  | some a,none => a
  | none,some b => b
  | none,none =>
    match u₁,u₂ with
    | some a,some b => min a b
    | some a,none => a
    | none,some b => b
    | none,none => 0

-- Closed integer intervals, possibly one-sided or unbounded.
theorem intersection_iff (l₁ u₁ l₂ u₂ : Option Int)
    (h₁ : Valid l₁ u₁) (h₂ : Valid l₂ u₂) :
    (∃ x : Int, Lower l₁ x ∧ Upper u₁ x ∧ Lower l₂ x ∧ Upper u₂ x) ↔
      Valid l₁ u₂ ∧ Valid l₂ u₁ := by
  constructor
  · rintro ⟨x,hx₁,hx₂,hx₃,hx₄⟩
    cases l₁ <;> cases u₁ <;> cases l₂ <;> cases u₂ <;>
      simp [Lower,Upper,Valid] at * <;> omega
  · intro h
    refine ⟨Pick l₁ l₂ u₁ u₂, ?_⟩
    cases l₁ <;> cases u₁ <;> cases l₂ <;> cases u₂ <;>
      simp [Lower,Upper,Valid,Pick] at * <;> omega

theorem difference_criterion
    (lt ut lc uc : Option Int) (offset et ec : Int)
    (ht : Valid lt ut) (hc : Valid lc uc)
    (het : 0 ≤ et) (hec : 0 ≤ ec) :
    (∃ g : Int,
      Lower lt (g+et) ∧ Upper ut (g-et) ∧
      Lower lc (g+offset+ec) ∧ Upper uc (g+offset-ec)) ↔
      Lower (SubOpt lc ut) (offset+et+ec) ∧
      Upper (SubOpt uc lt) (offset-et-ec) := by
  have tvalid : Valid (AddOpt lt (-et)) (AddOpt ut et) := by
    cases lt <;> cases ut <;> simp [Valid,AddOpt] at * <;> omega
  have cvalid : Valid (AddOpt lc (-offset-ec)) (AddOpt uc (-offset+ec)) := by
    cases lc <;> cases uc <;> simp [Valid,AddOpt] at * <;> omega
  have hi := intersection_iff (AddOpt lt (-et)) (AddOpt ut et)
      (AddOpt lc (-offset-ec)) (AddOpt uc (-offset+ec)) tvalid cvalid
  have e :
      (∃ g : Int, Lower lt (g+et) ∧ Upper ut (g-et) ∧
        Lower lc (g+offset+ec) ∧ Upper uc (g+offset-ec)) ↔
      (∃ g : Int, Lower (AddOpt lt (-et)) g ∧ Upper (AddOpt ut et) g ∧
        Lower (AddOpt lc (-offset-ec)) g ∧ Upper (AddOpt uc (-offset+ec)) g) := by
    constructor <;> rintro ⟨g,hg⟩ <;> refine ⟨g,?_⟩ <;>
      cases lt <;> cases ut <;> cases lc <;> cases uc <;>
      simp [Lower,Upper,AddOpt] at * <;> omega
  rw [e,hi]
  cases lt <;> cases ut <;> cases lc <;> cases uc <;>
    simp [Valid,AddOpt,SubOpt,Lower,Upper] at * <;> omega

-- This lemma connects every cell to an unrestricted common landscape.
-- Each cell may be one-sided or absent. The supplied offsets can be
-- any additive row-plus-column matrix, with no restrictions on shape.
theorem landscape_criterion {I J : Type}
    (lt ut lc uc : I → J → Option Int)
    (a : I → Int) (b : J → Int) (et ec : Int)
    (ht : ∀ i j, Valid (lt i j) (ut i j))
    (hc : ∀ i j, Valid (lc i j) (uc i j))
    (het : 0 ≤ et) (hec : 0 ≤ ec) :
    (∃ G : I → J → Int, ∀ i j,
      Lower (lt i j) (G i j+et) ∧ Upper (ut i j) (G i j-et) ∧
      Lower (lc i j) (G i j+a i+b j+ec) ∧
      Upper (uc i j) (G i j+a i+b j-ec)) ↔
    (∀ i j,
      Lower (SubOpt (lc i j) (ut i j)) (a i+b j+et+ec) ∧
      Upper (SubOpt (uc i j) (lt i j)) (a i+b j-et-ec)) := by
  classical
  constructor
  · rintro ⟨G,hG⟩ i j
    have h := (difference_criterion (lt i j) (ut i j) (lc i j) (uc i j)
      (a i+b j) et ec (ht i j) (hc i j) het hec).mp
        ⟨G i j,by simpa [Int.add_assoc] using hG i j⟩
    exact h
  · intro h
    have hex : ∀ i j, ∃ g : Int,
        Lower (lt i j) (g+et) ∧ Upper (ut i j) (g-et) ∧
        Lower (lc i j) (g+a i+b j+ec) ∧ Upper (uc i j) (g+a i+b j-ec) := by
      intro i j
      obtain ⟨g,hg⟩ := (difference_criterion (lt i j) (ut i j) (lc i j) (uc i j)
        (a i+b j) et ec (ht i j) (hc i j) het hec).mpr (h i j)
      exact ⟨g,by simpa [Int.add_assoc] using hg⟩
    exact ⟨fun i j => Classical.choose (hex i j), fun i j => Classical.choose_spec (hex i j)⟩

#print axioms intersection_iff
#print axioms difference_criterion
#print axioms landscape_criterion

end AssayCompatibility
