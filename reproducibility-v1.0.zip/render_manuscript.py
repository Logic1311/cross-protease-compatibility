#!/usr/bin/env python3
"""Render the English manuscript Markdown to a structured, searchable PDF.

Requires reportlab, matplotlib and Pillow. Does not bundle third-party fonts.
Page-level validation uses PyMuPDF separately.
"""
from pathlib import Path
import argparse
import html
import re
import tempfile
from io import BytesIO

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, LongTable, TableStyle, KeepTogether, HRFlowable

def register_fonts():
    fonts=Path("C:/Windows/Fonts")
    mapping={
        "TimesPaper":"times.ttf", "TimesPaper-Bold":"timesbd.ttf",
        "TimesPaper-Italic":"timesi.ttf", "TimesPaper-BoldItalic":"timesbi.ttf",
    }
    if not all((fonts/f).exists() for f in mapping.values()):
        mapping={"TimesPaper":"arial.ttf", "TimesPaper-Bold":"arialbd.ttf",
                 "TimesPaper-Italic":"ariali.ttf", "TimesPaper-BoldItalic":"arialbi.ttf"}
    for n,file in mapping.items():
        pdfmetrics.registerFont(TTFont(n,str(fonts/file)))
    pdfmetrics.registerFontFamily(
        "TimesPaper",normal="TimesPaper",bold="TimesPaper-Bold",
        italic="TimesPaper-Italic",boldItalic="TimesPaper-BoldItalic")

def styles():
    base=dict(textColor=colors.HexColor("#222222"),
              allowWidows=0,allowOrphans=0)
    return {
        "title":ParagraphStyle("TitleResearch",**base,fontSize=16,leading=20,
            alignment=TA_CENTER,spaceAfter=12,keepWithNext=True,fontName="TimesPaper-Bold"),
        "subtitle":ParagraphStyle("SubtitleResearch",**base,fontName="TimesPaper-Italic",fontSize=10.5,leading=14,
            alignment=TA_CENTER,spaceAfter=8,keepWithNext=True),
        "meta":ParagraphStyle("MetaResearch",**base,fontName="TimesPaper",fontSize=9,leading=13,
            alignment=TA_CENTER,spaceAfter=14,keepWithNext=True),
        "h2":ParagraphStyle("H2Research",**base,fontSize=12.4,leading=16,
            spaceBefore=14,spaceAfter=6,keepWithNext=True,
            fontName="TimesPaper-Bold"),
        "h3":ParagraphStyle("H3Research",**base,fontSize=10.7,leading=14,
            spaceBefore=12,spaceAfter=6,keepWithNext=True,
            fontName="TimesPaper-Bold"),
        "body":ParagraphStyle("BodyResearch",**base,fontName="TimesPaper",fontSize=9.6,leading=13.1,
            alignment=TA_LEFT,spaceAfter=8),
        "caption":ParagraphStyle("CaptionResearch",**base,fontName="TimesPaper",fontSize=8.4,leading=11.5,
            alignment=TA_CENTER,spaceBefore=4,spaceAfter=12),
        "equation":ParagraphStyle("EquationResearch",**base,fontName="TimesPaper",fontSize=10,leading=13,
            alignment=TA_CENTER,spaceBefore=6,spaceAfter=6),
        "tablecell":ParagraphStyle("TableCellResearch",**base,fontName="TimesPaper",fontSize=8.4,leading=10.6),
        "reference":ParagraphStyle("ReferenceResearch",**base,fontSize=8.8,leading=12,
            leftIndent=13,firstLineIndent=-13,spaceAfter=6),
    }

def convert_inline(text):
    s=html.escape(text)
    s=s.replace("kcal mol^-1","kcal mol<super>-1</super>")
    # ReportLab paragraphs can parse simple tags but not LaTeX.
    s=re.sub(r"\\\((.*?)\\\)",lambda m:html.escape(m.group(1)
        .replace("\\delta_\\star","delta*").replace("\\delta","delta")
        .replace("\\Omega","Omega").replace("\\mathrm","")
        .replace("{","").replace("}","").replace("\\","")),s)
    s=re.sub(r"\*\*([^*]+)\*\*",r"<b>\1</b>",s)
    s=re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)",r"<i>\1</i>",s)
    return s

def math_image(expr,width):
    expr=expr.strip()
    if expr.startswith("$$"):expr=expr[2:]
    if expr.endswith("$$"):expr=expr[:-2]
    expr=expr.strip().replace("\n"," ")
    expr=re.sub(r"\\ge(?!q)",r"\\geq",expr).replace(r"\leqft",r"\left")
    expr=expr.replace(r"\operatorname",r"\mathrm")
    buf=BytesIO()
    fig=plt.figure(figsize=(9.3,0.9),dpi=200)
    fig.patch.set_alpha(0)
    plt.text(.5,.5,"$"+expr+"$",fontsize=14,ha="center",va="center")
    plt.axis("off")
    try:
        fig.savefig(buf,format="png",transparent=True,bbox_inches="tight",pad_inches=.09)
    except ValueError as e:
        plt.close(fig)
        raise RuntimeError(f"Math rendering failed for {expr!r}: {e}")
    plt.close(fig)
    buf.seek(0)
    im=PILImage.open(buf)
    w,h=im.size
    final_width=min(width*.95,w*.45)
    final_height=final_width*h/w
    buf.seek(0)
    return Image(buf,width=final_width,height=final_height,hAlign="CENTER")

def image_flowable(file,available):
    im=PILImage.open(file)
    w,h=im.size
    dw=min(available*.95,425.)
    return Image(str(file),width=dw,height=dw*h/w,hAlign="CENTER")

def parse_markdown(src,width,sty):
    lines=src.splitlines()
    content=[]
    tmp=[]
    def flush():
        nonlocal tmp
        if tmp:
            p=" ".join(tmp).strip()
            if p:
                isref=bool(re.match(r"^\[\d+\]",p))
                content.append(Paragraph(convert_inline(p),sty["reference" if isref else "body"]))
            tmp=[]
    i=0
    while i<len(lines):
        s=lines[i].strip()
        if not s:
            flush();i+=1;continue
        if s.startswith("$$"):
            flush()
            items=[s]
            if s.count("$$")<2:
                i+=1
                while i<len(lines):
                    v=lines[i].strip()
                    items.append(v)
                    if "$$" in v:break
                    i+=1
            content.append(math_image(" ".join(items),width))
            content.append(Spacer(1,4))
            i+=1;continue
        if s.startswith("!["):
            flush()
            mt=re.match(r"!\[([^\]]*)\]\(([^)]*)\)",s)
            if not mt:raise AssertionError(s)
            caption,path=mt.groups()
            asset=(Path(src.base_dir)/path).resolve() # src has a base_dir field assigned below
            if not asset.exists():raise FileNotFoundError(asset)
            content.append(image_flowable(asset,width))
            content.append(Paragraph(html.escape(caption),sty["caption"]))
            i+=1;continue
        if s.startswith("|"):
            flush()
            buf=[]
            while i<len(lines) and lines[i].lstrip().startswith("|"):
                buf.append(lines[i]);i+=1
            rows=[[part.strip() for part in line.strip().strip("|").split("|")] for line in buf]
            rows=[r for r in rows if not all(re.fullmatch(r":?-{2,}:?",v) for v in r)]
            ncol=max(len(r) for r in rows)
            if ncol==3:
                colW=[110,width-110-118,118]
            else:colW=[width/ncol]*ncol
            cells=[]
            for row in rows:
                cells.append([Paragraph(convert_inline(x),sty["tablecell"]) for x in row])
            tab=LongTable(cells,colWidths=colW,repeatRows=1,hAlign="CENTER")
            tab.setStyle(TableStyle([
                ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#eaeaea")),
                ("GRID",(0,0),(-1,-1),.35,colors.HexColor("#c4c4c4")),
                ("VALIGN",(0,0),(-1,-1),"TOP"),
                ("LEFTPADDING",(0,0),(-1,-1),5),
                ("RIGHTPADDING",(0,0),(-1,-1),5),
                ("TOPPADDING",(0,0),(-1,-1),4),
                ("BOTTOMPADDING",(0,0),(-1,-1),4),
            ]))
            content.append(tab);content.append(Spacer(1,9))
            continue
        if s.startswith("### "):
            flush();content.append(Paragraph(convert_inline(s[4:]),sty["h3"]));i+=1;continue
        if s.startswith("## "):
            flush();content.append(Paragraph(convert_inline(s[3:]),sty["h2"]));i+=1;continue
        if s.startswith("# "):
            flush();content.append(Paragraph(convert_inline(s[2:]),sty["title"]));i+=1;continue
        if s.startswith("*") and s.endswith("*") and not s.startswith("**"):
            flush();content.append(Paragraph(convert_inline(s),sty["subtitle"]));i+=1;continue
        if s.startswith("**") and s.endswith("**") and "version" in s:
            flush();content.append(Paragraph(convert_inline(s),sty["meta"]));i+=1;continue
        tmp.append(s)
        i+=1
    flush()
    return content

class Source(str):
    def __new__(cls,text,base_dir):
        obj=str.__new__(cls,text)
        obj.base_dir=str(base_dir)
        return obj

def render(root):
    register_fonts()
    source=root/"manuscript"/"manuscript.md"
    out=root/"manuscript"/"manuscript.pdf"
    txt=Source(source.read_text(encoding="utf-8-sig"),source.parent)
    sty=styles()
    doc=SimpleDocTemplate(str(out),pagesize=A4,
        leftMargin=51,rightMargin=51,topMargin=45,bottomMargin=52,
        title="Censor-aware compatibility budgets for paired protein-folding assays",
        author="Research author information pending",subject="Nonadditive protein folding stability")
    def page(canvas,document):
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor("#b4b4b4"))
        canvas.line(51,41,A4[0]-51,41)
        canvas.setFont("TimesPaper",8)
        canvas.drawString(51,29,"Research manuscript v1.0 | not peer reviewed | 26 November 2026")
        canvas.drawRightString(A4[0]-51,29,f"{document.page}")
        canvas.restoreState()
    story=parse_markdown(txt,A4[0]-102,sty)
    doc.build(story,onFirstPage=page,onLaterPages=page)
    print(out, out.stat().st_size)

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--root",required=True,type=Path)
    render(p.parse_args().root)






